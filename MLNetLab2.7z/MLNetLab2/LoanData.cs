﻿using Microsoft.ML.Data;
namespace MLNetLab2
{
    public class LoanData
    {
        [LoadColumn(1)]
        public string Gender { get; set; }
        [LoadColumn(2)]
        public string Married { get; set; }
        [LoadColumn(3)]
        public string Dependents { get; set; }
        [LoadColumn(4)]
        public string Education { get; set; }
        [LoadColumn(5)]
        public string Self_Employed { get; set; }
        [LoadColumn(6)]
        public int ApplicantIncome { get; set; }
        [LoadColumn(7)]
        public float CoapplicantIncome { get; set; }
        [LoadColumn(8)]
        public int LoanAmount { get; set; }
        [LoadColumn(9)]
        public int LoanAmountTerm { get; set; }
        [LoadColumn(10)]
        public bool Credit_History { get; set; }
        [LoadColumn(11)]
        public string Property_Area { get; set; }
        [LoadColumn(12)]
        public string Loan_Status { get; set; }
    }

    public class LoanDataTransformed
    {
        public bool Loan_Status_Bool { get; set; }

        public Single ApplicantIncome_Single { get; set; }
        public Single CoapplicantIncome_Single { get; set; }
        public Single LoanAmount_Single { get; set; }
        public Single LoanAmountTerm_Single { get; set; }
        public Single Property_Area_Single { get; set; }
    }


    public class LoanReliabilityPrediction
    {
        [ColumnName("PredictedLabel")]
        public bool Prediction { get; set; }

        public float Probability { get; set; }

        public float Score { get; set; }
    }
}
