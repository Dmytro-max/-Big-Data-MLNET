﻿using Microsoft.ML;
using Microsoft.ML.Data;


namespace MLNetLab2
{
    internal class BinaryClassifierTrainer
    {
        private MLContext mlContext;
        private ITransformer model;

        public BinaryClassifierTrainer()
        {
            mlContext = new MLContext();
        }

        public ITransformer CreateAndTrainModel(string dataPath = "data.csv")
        {
            var pipeline =
                mlContext.Transforms.Conversion.MapValue("Loan_Status_Bool", new Dictionary<string, bool>
                    {
                        { "Y", true },
                        { "N", false }
                    }, "Loan_Status")
                .Append(
                mlContext.Transforms.Conversion.ConvertType(
                    new[]
                    {
                        new InputOutputColumnPair("ApplicantIncome_Single", "ApplicantIncome"),
                        new InputOutputColumnPair("CoapplicantIncome_Single", "CoapplicantIncome"),
                        new InputOutputColumnPair("LoanAmount_Single", "LoanAmount"),
                        new InputOutputColumnPair("LoanAmountTerm_Single", "LoanAmountTerm"),
                        new InputOutputColumnPair("Property_Area_Single", "Property_Area"),
                    },
                DataKind.Single))
                .Append
            (mlContext.Transforms.Categorical.OneHotEncoding(
                new[]
                {
                    new InputOutputColumnPair("Dependents_Categorical", "Dependents"),
                    new InputOutputColumnPair("Education_Categorical", "Education"),
                    new InputOutputColumnPair("Self_Employed_Categorical", "Self_Employed"),
                    new InputOutputColumnPair("Gender_Categorical", "Gender"),
                    new InputOutputColumnPair("Married_Categorical", "Married"),
                    new InputOutputColumnPair("Credit_History_Categorical", "Credit_History"),
                    new InputOutputColumnPair("Property_Area_Categorical", "Property_Area"),
                }
            ))
            .Append(mlContext.Transforms.Concatenate("Features", new[]
            {
                "Gender_Categorical", "Married_Categorical", "Dependents_Categorical", "Education_Categorical", "Self_Employed_Categorical", "ApplicantIncome_Single", "CoapplicantIncome_Single", "LoanAmount_Single", "LoanAmountTerm_Single", "Credit_History_Categorical", "Property_Area_Categorical"
            }))
            .Append(mlContext.Transforms.NormalizeMinMax("Features"))
            .Append(mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Loan_Status_Bool"));

            IDataView dataView = mlContext.Data.LoadFromTextFile<LoanData>(dataPath, hasHeader: true, separatorChar: ',');

            // Ensure stratified split
            var stratifiedSplit = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.25);
            var trainData = stratifiedSplit.TrainSet;
            var testData = stratifiedSplit.TestSet;


            model = pipeline.Fit(trainData);
            var prediction = model.Transform(testData);
            var metrics = mlContext.BinaryClassification.Evaluate(prediction, labelColumnName: "Loan_Status_Bool");

            Console.WriteLine($"Area Under Precision-Recall Curve: {metrics.AreaUnderPrecisionRecallCurve}");
            Console.WriteLine($"Accuracy: {metrics.Accuracy}");
            Console.WriteLine($"Area Under ROC Curve: {metrics.AreaUnderRocCurve}");

            return model;
        }


        public string SaveModel(string saveLocation = "D:")
        {
            var modelPath = saveLocation + "\\LoanReliabilityModel.zip";
            mlContext.Model.Save(model, null, modelPath);
            Console.WriteLine($"Model successfully saved to {modelPath}");

            return modelPath;
        }
    }
}