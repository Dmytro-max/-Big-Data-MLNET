﻿
using Microsoft.ML;

namespace MLNetLab2
{
    internal class BinaryClassificationModel_Loader
    {
        public BinaryClassificationModel_Loader()
        {
            mlContext = new MLContext();
        }

        MLContext mlContext;
        ITransformer predictionModel;

        public ITransformer LoadModel(String filePath = "D:\\Projects\\source\\LoanReliabilityModel.zip")
        {
            DataViewSchema modelSchema;

            predictionModel = mlContext.Model.Load(filePath, out modelSchema);

            return predictionModel;
        }


        public void Predict(LoanData loanData)
        {
            PredictionEngine<LoanData, LoanReliabilityPrediction> predictionEngine = mlContext.Model.CreatePredictionEngine<LoanData, LoanReliabilityPrediction>(predictionModel);

            LoanReliabilityPrediction prediction = predictionEngine.Predict(loanData);

            Console.WriteLine($"Predicted for Gender:{loanData.Gender}, Married:{loanData.Married}, Dependents:{loanData.Dependents}, Education:{loanData.Education}, Self_Employed:{loanData.Self_Employed}, ApplicantIncome:{loanData.ApplicantIncome}, CoapplicantIncome:{loanData.CoapplicantIncome}, LoanAmount:{loanData.LoanAmount}, LoanAmountTerm:{loanData.LoanAmountTerm}, Credit_History:{loanData.Credit_History}, Property_Area:{loanData.Property_Area}\n Reliable: {prediction.Prediction}");
        }

        public void PredictBatch(LoanData[] loanDataset)
        {
            PredictionEngine<LoanData, LoanReliabilityPrediction> predictionEngine = mlContext.Model.CreatePredictionEngine<LoanData, LoanReliabilityPrediction>(predictionModel);

            foreach (var loanData in loanDataset)
            {
                LoanReliabilityPrediction prediction = predictionEngine.Predict(loanData);

                Console.WriteLine($"Predicted for Gender:{loanData.Gender}, Married:{loanData.Married}, Dependents:{loanData.Dependents}, Education:{loanData.Education}, Self_Employed:{loanData.Self_Employed}, ApplicantIncome:{loanData.ApplicantIncome}, CoapplicantIncome:{loanData.CoapplicantIncome}, LoanAmount:{loanData.LoanAmount}, LoanAmountTerm:{loanData.LoanAmountTerm}, Credit_History:{loanData.Credit_History}, Property_Area:{loanData.Property_Area}\n Reliable: {prediction.Prediction}\n Probability: {prediction.Probability}\n Score: {prediction.Score}");
            }
        }

    }
}

