﻿using Microsoft.ML;

namespace MLNetLab1
{
    internal class ModelLoader
    {
        public ModelLoader()
        {
            mlContext = new MLContext();
        }

        MLContext mlContext;
        ITransformer predictionModel;

        public ITransformer LoadModel(String filePath = "D:\\Projects\\source\\TeslaCostsModel.zip")
        {
            DataViewSchema modelSchema;

            predictionModel = mlContext.Model.Load(filePath, out modelSchema);

            return predictionModel;
        }


        public void Predict(TeslaCostsData teslaData)
        {
            PredictionEngine<TeslaCostsData, TeslaCostsPrediction> predictionEngine = mlContext.Model.CreatePredictionEngine<TeslaCostsData, TeslaCostsPrediction>(predictionModel);

            TeslaCostsPrediction prediction = predictionEngine.Predict(teslaData);

            Console.WriteLine($"Predicted for Open:{teslaData.Open}, High:{teslaData.High}, Low:{teslaData.Low}, Close:{teslaData.Close}\n Volume: {prediction.Volume}");
        }

        public void PredictBatch(TeslaCostsData[] teslaData)
        {

            PredictionEngine<TeslaCostsData, TeslaCostsPrediction> predictionEngine = mlContext.Model.CreatePredictionEngine<TeslaCostsData, TeslaCostsPrediction>(predictionModel);

            foreach (var example in teslaData)
            {
                TeslaCostsPrediction prediction = predictionEngine.Predict(example);
                Console.WriteLine($"Predicted for Open:{example.Open}, High:{example.High}, Low:{example.Low}, Close:{example.Close}\n Volume: {prediction.Volume}");
            }
        }

    }
}
