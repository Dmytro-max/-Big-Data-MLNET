﻿using Microsoft.ML;
using static Microsoft.ML.DataOperationsCatalog;

namespace MLNetLab1
{
    public class RegressionModelTrainer
    {
        public RegressionModelTrainer()
        {
            mlContext = new MLContext();
        }

        private MLContext mlContext;
        private ITransformer model;

        public ITransformer createModel(String dataPath = "D:\\")
        {

            IDataView dataView = mlContext.Data.LoadFromTextFile<TeslaCostsData>(
                dataPath,
                hasHeader: true,
                separatorChar: ',',
                allowQuoting: true);


            TrainTestData trainTestData = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.25);
            IDataView trainData = trainTestData.TrainSet;
            IDataView testData = trainTestData.TestSet;


            var pipeline = mlContext.Transforms.Concatenate("Features", new[] { 
                    "Open", "High", "Low", "Close"
                    , "Volume"
                })
                .Append(mlContext.Transforms.NormalizeMinMax("Features"))
                .Append(mlContext.Regression.Trainers.FastTreeTweedie(labelColumnName: "Volume"));

            //Fitting data
            model = pipeline.Fit(dataView);
            var prediction = model.Transform(testData);
            var metrics = mlContext.Regression.Evaluate(prediction, labelColumnName: "Volume");

            Console.WriteLine($"R^2: {metrics.RSquared}\n MeanSquaredError: {metrics.MeanSquaredError}\n MeanAbsoluteError: {metrics.MeanAbsoluteError}");

            return model;
        }

        public string SaveModel(String saveLocation="D:")
        {
            var modelPath = saveLocation + "\\TeslaCostsModel.zip";
            mlContext.Model.Save(model, null, modelPath);
            Console.WriteLine($"Model succesfully saved to {modelPath}");

            return modelPath;
        }
    }
}
