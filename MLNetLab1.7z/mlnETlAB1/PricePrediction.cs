﻿using Microsoft.ML.Data;

namespace MLNetLab1_2
{
    internal class TeslaCostsPrediction
    {
        [ColumnName("Score")]
        public float Volume { get; set; }
    }
}
