﻿using Microsoft.ML.Data;

namespace MLNetLab1
{
    public class TeslaCostsPrediction
    {
        [ColumnName("Score")]
        public float Volume { get; set; }
    }
}
