﻿using Microsoft.ML;
using MLNetLab1;
using static Microsoft.ML.DataOperationsCatalog;

internal class Program
{
    private static void Main(string[] args)
    {
        {
            MLContext mlContext = new MLContext();
            // Load the data
            String dataPath = ("D:\\Projects\\source\\mlnETlAB1\\tesla.csv");
            {
                //IDataView dataView = mlContext.Data.LoadFromTextFile<TeslaCostsData>(
                //    dataPath,
                //    hasHeader: true, 
                //    separatorChar: ',',
                //    allowQuoting: true);


                //TrainTestData trainTestData = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.25);
                //IDataView trainData = trainTestData.TrainSet;
                //IDataView testData = trainTestData.TestSet;


                //var pipeline = mlContext.Transforms.Concatenate("Features", new[] {                     "Open", "High", "Low", "Close"
                //        , "Volume"
                //    })
                //    .Append(mlContext.Transforms.NormalizeMinMax("Features"))
                //    .Append(mlContext.Regression.Trainers.FastTreeTweedie(labelColumnName: "Volume"));

                ////Fitting data
                //var model = pipeline.Fit(dataView);
                //var prediction = model.Transform(testData);
                //var metrics = mlContext.Regression.Evaluate(prediction, labelColumnName: "Volume");

                //Console.WriteLine($"R^2: {metrics.RSquared}\n MeanSquaredError: {metrics.MeanSquaredError}\n MeanAbsoluteError: {metrics.MeanAbsoluteError}");

                //SaveModel(mlContext, model, "D:\\Projects\\source");
            }

            RegressionModelTrainer regressionTrainer = new RegressionModelTrainer();
            regressionTrainer.createModel("D:\\Projects\\source\\mlnETlAB1\\tesla.csv");

            String modelPath = regressionTrainer.SaveModel("D:\\Projects\\source");


            ModelLoader modelLoader = new ModelLoader();
            ITransformer predictionModel = modelLoader.LoadModel(modelPath);

            modelLoader.PredictBatch(new TeslaCostsData[]
            {
                new TeslaCostsData{
                    Open = 170,
                    High = 190,
                    Low = 150,
                    Close = 180,
                },
                new TeslaCostsData{
                    Open = 170,
                    High = 220,
                    Low = 150,
                    Close = 200,
                },
                new TeslaCostsData{
                    Open = 170,
                    High = 250,
                    Low = 150,
                    Close = 240,
                },
                new TeslaCostsData{
                    Open = 200,
                    High = 260,
                    Low = 150,
                    Close = 240,
                },
                new TeslaCostsData{
                    Open = 120,
                    High = 260,
                    Low = 90,
                    Close = 240,
                },
            });
        }
    }
        public static string SaveModel(MLContext mlContext, ITransformer model, String saveLocation="D:")
        {
            var modelPath = saveLocation + "\\TeslaCostsModel.zip";
            mlContext.Model.Save(model, null, modelPath);
            Console.WriteLine($"Model saved to {modelPath}");

            return modelPath;
        }

    }